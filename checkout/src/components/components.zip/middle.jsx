import styled from 'styled-components';

const Plane= styled.div`
background-color:rgb(255,252,199);
border-radius:20px;
padding: 1%;
text-align:center;
`
export function Middle(){
return (
    <Plane>
        Changes planes at Jaipur(JAI), Connecting Time:12h20m
    </Plane>
)
}